# OLake Helm Chart

<h1 align="center" style="border-bottom: none">
    <a href="https://datazip.io/olake" target="_blank">
        <img alt="olake" src="https://github.com/user-attachments/assets/d204f25f-5289-423c-b3f2-44b2194bdeaf" width="100" height="100"/>
    </a>
    <br>OLake
</h1>

<p align="center">Fastest open-source tool for replicating Databases to Apache Iceberg or Data Lakehouse. ⚡ Efficient, quick and scalable data ingestion for real-time analytics. Starting with MongoDB. Visit <a href="https://olake.io/" target="_blank">olake.io/docs</a> for the full documentation, and benchmarks</p>

<p align="center">
    <a href="https://github.com/datazip-inc/olake-ui/issues"><img alt="GitHub issues" src="https://img.shields.io/github/issues/datazip-inc/olake"/></a> <a href="https://olake.io/docs"><img alt="Documentation" height="22" src="https://img.shields.io/badge/view-Documentation-blue?style=for-the-badge"/></a>
    <a href="https://join.slack.com/t/getolake/shared_invite/zt-2utw44do6-g4XuKKeqBghBMy2~LcJ4ag"><img alt="slack" src="https://img.shields.io/badge/Join%20Our%20Community-Slack-blue"/></a>
</p>

## Components

-   **OLake UI**: The main application providing user interface and backend API
-   **OLake Worker**: Kubernetes-native worker executing data synchronization, discovery, and testing tasks
-   **Temporal**: Workflow orchestration engine managing data ingestion pipeline lifecycle
-   **PostgreSQL**: Primary data store for both OLake application and Temporal
-   **Elasticsearch**: Advanced visibility and search capabilities for Temporal
-   **NFS Server**(Optional): Self-managed in-cluster NFS server with dynamic provisioning for shared storage

## Prerequisites

-   Kubernetes 1.19+
-   Helm 3.2.0+

## Installation

### Step 1: Add the OLake Helm Repository
```bash
helm repo add olake https://datazip-inc.github.io/olake-helm
helm repo update
```

### Step 2: Install the Chart
```bash
# Using default values.yaml file
helm install olake olake/olake
```

A custom values file could be crafted that would define/override any of the values exposed into the default [values.yaml](https://github.com/datazip-inc/olake-helm/helm/olake/values.yaml).
```bash
# Using the crafted my-values.yaml file
helm install --values my-values.yaml olake olake/olake
```

### Step 3: Access the OLake UI
```bash
# The UI service port (8080) needs to be forwarded to the local machine
kubectl port-forward svc/olake-ui 8000:8000

# Now, open a browser and head over to http://localhost:8000
```
Perform the login with the default credentials: `admin` / `password`.

**Note:** If OLake is installed with Ingress enabled, port-forwarding is not necessary. Access the application using the configured Ingress hostname.

## Upgrading

```bash
# Upgrade to latest version
helm upgrade olake olake/olake

# Upgrade with new values
helm upgrade olake olake/olake -f new-values.yaml
```

## Configuring the Helm Chart

### Updating OLake UI Version

Pull the latest images and restart the deployments without downtime:

```bash
# Restart OLake components
kubectl rollout restart deployment/olake-ui
kubectl rollout restart deployment/olake-workers
```

### Initial User Setup

For enhanced security, the default admin user credentials could be replaced by using a pre-existing Kubernetes secret.

#### 1. Create a Kubernetes secret
```bash
kubectl create secret generic olake-admin-credentials \
  --from-literal=username='superadmin' \
  --from-literal=password='a-very-secure-password' \
  --from-literal=email='admin@mycompany.com'
```

#### 2. Use the secret in `values.yaml`
```yaml
olakeUI:
  initUser:
    # Reference the newly created secret. This automaticaly overwrites the initial admin credentials
    existingSecret: "olake-admin-credentials"
    secretKeys:
      username: "username"
      password: "password"
      email: "email"
```

### Ingress Configuration

The OLake UI can be exposed using an Ingress. Any Ingress controller can be used; however, the following example assumes the use of the Nginx Ingress controller and includes annotations specific to it.

```yaml
olakeUI:
  ingress:
    enabled: true
    className: "nginx"
    annotations:
      nginx.ingress.kubernetes.io/rewrite-target: /
    hosts:
      - host: olake.example.com
        paths:
          - path: /
            pathType: Prefix
    tls:
      - secretName: olake-tls
        hosts:
          - olake.example.com
```

### JobID-Based Scheduling
With this powerful feature, data jobs can be routed to specific Kubernetes nodes with advanced scheduling controls.

_**Where is the JobID found?**_ The JobID is an integer that is automatically assigned to each job created in OLake UI. The JobID can be found in the corresponding row for each job on the Jobs page.

```yaml
global:
  jobProfiles:
    123: # JobID
      nodeSelector:
        olake.io/workload-type: "heavy"
      tolerations:
        - key: "heavy-workload"
          operator: "Equal"
          value: "true"
          effect: "NoSchedule"
    456: # JobID
      tolerations:
        - key: "spot-instance"
          operator: "Exists"
          effect: "NoSchedule"
      affinity:
        nodeAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
            nodeSelectorTerms:
              - matchExpressions:
                  - key: "olake.io/workload-type"
                    operator: "In"
                    values:
                      - "small"
    0: # Default profile for unmapped jobs
      nodeSelector:
        olake.io/workload-type: "general"
```

- If `"0"` (Default) is configured, it is used for all unmapped jobs and other activities (Fetch, Test, Discover).
- If `"0"` is NOT configured, unmapped jobs are scheduled by the standard Kubernetes scheduler on any available node.

**Deprecation Notice:** The legacy `global.jobMapping` configuration (which only supported `nodeSelector`) is deprecated and will be removed in a future release. Users are strongly advised to migrate to `global.jobProfiles`, which provides feature-rich scheduling capabilities including tolerations and affinity rules.

### Cloud IAM Integration

OLake's "activity pods" (the pods by which the actual data sync is performed) can be allowed to securely access cloud resources(AWS Glue or S3) using IAM roles.

**Note:** For detailed instructions on the creation of IAM roles and service accounts, the official documentation for [AWS IRSA](https://docs.aws.amazon.com/eks/latest/userguide/iam-roles-for-service-accounts.html), [GCP Workload Identity](https://cloud.google.com/kubernetes-engine/docs/how-to/workload-identity), or [Azure Workload Identity](https://learn.microsoft.com/en-us/azure/aks/workload-identity-deploy-cluster) should be referred to. For a minimal Glue and S3 IAM access policy please refer: https://olake.io/docs/writers/iceberg/catalog/glue#required-iam-permissions

```yaml
global:
  jobServiceAccount:
    # Create a service account for job pods
    create: true
    name: "olake-job-sa"
    
    # Cloud provider IAM role associations
    annotations:
      # AWS IRSA
      eks.amazonaws.com/role-arn: "arn:aws:iam::123456789012:role/olake-job-role"
      
      # GCP Workload Identity
      iam.gke.io/gcp-service-account: "olake-job@project.iam.gserviceaccount.com"
      
      # Azure Workload Identity
      azure.workload.identity/client-id: "12345678-1234-1234-1234-123456789012"
```

### Encryption Configuration

Configure encryption of job metadata stored in Postgres database by setting the `OLAKE_SECRET_KEY` environment variable in the OLake Worker:

```yaml
global:
  env:
    # 1. For AWS KMS (starts with 'arn:aws:kms:'):
    OLAKE_SECRET_KEY: "arn:aws:kms:us-west-2:123456789012:key/12345678-1234-1234-1234-123456789012"

    # 2. For local AES-256 (any other non-empty string):
    OLAKE_SECRET_KEY: "your-secret-encryption-key"  # Auto-hashed to 256-bit key

    # 3. For no encryption (not recommended for production):
    # OLAKE_SECRET_KEY: ""  # Empty = no encryption
```

### Shared Storage Configuration

The OLake application components (UI, Worker, and Activity Pods) require a shared ReadWriteMany (RWX) volume for **coordinating pipeline state and metadata**.

For production, a robust, highly-available RWX-capable storage solution such as [AWS EFS](https://github.com/kubernetes-sigs/aws-efs-csi-driver), [GKE Filestore](https://cloud.google.com/filestore/docs/csi-driver), or [Azure Files](https://docs.microsoft.com/en-us/azure/aks/azure-files-csi) must be used. This is achieved by disabling the built-in NFS server and providing an existing Kubernetes StorageClass that is backed by a managed storage service. An example for using StorageClass given below:

```yaml
nfsServer:
  # 1. The development NFS server is disabled
  enabled: false
  
  # 2. An existing ReadWriteMany supported StorageClass is specified
  external:
    storageClass: "efs-csi"
```

**Note:** For development and quick starts, a simple NFS server is included and enabled by default. This provides an out-of-the-box shared storage solution without any external dependencies. However, because this server runs as a single pod, it represents a single point of failure and is not recommended for production use.

**⚠️ Bottlerocket OS on AWS EKS:** The built-in NFS server is incompatible with Bottlerocket OS worker nodes. For such AWS EKS configurations, AWS EFS must be used as an alternative, which requires setting `nfsServer.enabled: false` and configuring the EFS CSI driver.

### External PostgreSQL Configuration

External PostgreSQL databases can be used instead of the built-in postgresql deployment. It is the primary database for storing job data, configurations, and sync state.

**Requirements:**
- PostgreSQL 12+ with `btree_gin` extension enabled
- Both OLake and Temporal databases created on the PostgreSQL instance
- Network connectivity from Kubernetes cluster to PostgreSQL instance

There are two ways to configure an external PostgreSQL database:

#### Option 1: Using `existingSecret`

Reference a pre-existing Kubernetes Secret containing the database credentials. The secret must be created manually before installing the chart.

**1. Create the database secret:**
```bash
kubectl create secret generic external-postgres-secret \
  --from-literal=host="postgres-host" \
  --from-literal=port="5432" \
  --from-literal=olake_database="olakeDB" \
  --from-literal=temporal_database="temporalDB" \
  --from-literal=username="username" \
  --from-literal=password="password" \
  --from-literal=ssl_mode="require"
```

**2. Configure `values.yaml`:**
```yaml
postgresql:
  enabled: false
  external:
    existingSecret: "external-postgres-secret"
```

**Warning:** When using `existingSecret`, SSL/TLS settings for Temporal rely on Helm's `lookup` function to read the secret at install time. This requires direct cluster access and does **not** work with ArgoCD or any tool that renders templates offline via `helm template`. If you are deploying with ArgoCD, use **Option 2** instead.

#### Option 2: Using `properties` (Recommended for ArgoCD/GitOps)

Specify the database connection details directly in `values.yaml`. The chart automatically creates a Kubernetes Secret from these values at template time. This approach is fully compatible with ArgoCD and other GitOps tools that use `helm template` for rendering.

```yaml
postgresql:
  enabled: false
  external:
    properties:
      host: "postgres-host"
      port: 5432
      username: "username"
      password: "password"
      olake_database: "olakeDB"
      temporal_database: "temporalDB"
      ssl_mode: "require"
```

### External Temporal Configuration

By default, OLake deploys an internal Temporal instance. To use [Temporal Cloud](https://temporal.io/cloud) or a self-hosted external Temporal server, disable the built-in deployment and supply connection credentials. Set `temporal.enabled: false` and configure credentials using one of the two options below.

#### Option 1: Using `existingSecret`

Reference a pre-existing Kubernetes Secret containing the Temporal credentials. The secret must be created before installing the chart.

**1. Create the secret:**
```bash
kubectl create secret generic external-temporal-secret \
  --from-literal=TEMPORAL_ADDRESS=<region>.<cloud>.api.temporal.io:7233 \
  --from-literal=TEMPORAL_API_KEY=<temporal-api-key> \
  --from-literal=TEMPORAL_ENABLE_TLS=true \
  --from-literal=TEMPORAL_EXTERNAL=true \
  --from-literal=TEMPORAL_NAMESPACE=<temporal-namespace> \
  --from-literal=TEMPORAL_TASK_QUEUE=<temporal-task-queue>
```

**2. Configure `values.yaml`:**
```yaml
temporal:
  enabled: false
  external:
    existingSecret: "external-temporal-secret"
```

#### Option 2: Using `properties` (Recommended for ArgoCD/GitOps)

Specify connection details directly in `values.yaml`. The chart creates the Kubernetes Secret automatically at template time.

```yaml
temporal:
  enabled: false
  external:
    properties:
      TEMPORAL_ADDRESS: "<region>.<cloud>.api.temporal.io:7233"
      TEMPORAL_API_KEY: "<temporal-api-key>"
      TEMPORAL_ENABLE_TLS: "true"
      TEMPORAL_EXTERNAL: "true"
      TEMPORAL_NAMESPACE: "<temporal-namespace>"
      TEMPORAL_TASK_QUEUE: "<temporal-task-queue>"
```

### Global Environment Variables

Environment variables defined in `global.env` are automatically propagated to OLake UI, OLake Workers, and Activity Pods:

```yaml
global:
  env:
    OLAKE_SECRET_KEY: "your-secret-encryption-key"
    RUN_MODE: "production"
    # Add any custom environment variables here
```

### Global Pod Annotations

Annotations defined in `global.podAnnotations` are applied to every pod managed by this chart — all Deployment pods (OLake UI, OLake Workers, PostgreSQL, Temporal, Elasticsearch, Fusion), Fusion Spark optimizer pods, and connector activity pods (sync, discover, check) spawned by olake-workers.

This is useful for service mesh sidecar injection (Istio, Linkerd) or any admission-webhook-based tooling that requires pod-level annotations.

```yaml
global:
  podAnnotations:
    sidecar.istio.io/inject: "true"
    linkerd.io/inject: enabled
```

**Activity pods:** annotations are read by olake-workers from the `OLAKE_JOB_POD_ANNOTATIONS` configmap key and merged into the connector Job pod spec at runtime. Internal `olake.io/*` annotations always take precedence over user-supplied ones.

### Private Container Registry

OLake supports pulling all images from a private or self-hosted container registry.

#### Step 1 — Point OLake at the registry

Setting `CONTAINER_REGISTRY_BASE` in `global.env` causes every image reference in the chart to be automatically prefixed with that value — no per-image overrides are needed.

```yaml
global:
  env:
    CONTAINER_REGISTRY_BASE: "registry.example.com/myproject"
```

The following images must be mirrored to the registry before deploying:

| Image | Source |
|---|---|
| `library/busybox:latest` | Docker Hub |
| `curlimages/curl:8.1.2` | Docker Hub |
| `olakego/ui:latest`, `olakego/ui-worker:latest` | Docker Hub |
| `olakego/source-*` (e.g. `olakego/source-mongodb:v0.7.0`) | Docker Hub |
| `temporalio/auto-setup:1.22.3`, `temporalio/ui:2.16.2` | Docker Hub |
| `library/postgres:14-alpine` | Docker Hub |
| `olakego/fusion:latest`, `olakego/fusion-spark:latest` | Docker Hub |
| `sig-storage/nfs-provisioner:v4.0.8` | `registry.k8s.io` (built-in NFS only) |

#### Step 2 — Authenticate with the registry

If the registry requires credentials, a Kubernetes docker-registry secret must be created:

```bash
kubectl create secret docker-registry my-registry-secret \
  --docker-server=registry.example.com \
  --docker-username=<username> \
  --docker-password=<password>
```

The secret is then referenced in `values.yaml`:

```yaml
global:
  imagePullSecrets:
    - name: my-registry-secret

  env:
    CONTAINER_REGISTRY_BASE: "registry.example.com/myproject"
```

> **Note:** For cloud-managed registries (Amazon ECR, Google Artifact Registry, Azure ACR), IAM-based authentication (IRSA / Workload Identity) is preferred over static credentials. See [Cloud IAM Integration](#cloud-iam-integration).

## Monitoring and Troubleshooting

### View Logs

```bash
# OLake UI logs
kubectl logs -l app.kubernetes.io/name=olake-ui -f

# OLake Worker logs
kubectl logs -l app.kubernetes.io/name=olake-workers -f
```

### Common Issues

1. **Pod deployment failures**
   ```bash
   # Check pod status across all components
   kubectl get pods -l app.kubernetes.io/instance=olake
   
   # Describe problematic pods for detailed error information
   kubectl describe pod <pod-name>
   
   # Check recent events for deployment issues
   kubectl get events --sort-by='.lastTimestamp' --field-selector type!=Normal
   ```

2. **OLake UI not starting**
   ```bash
   # Check UI pod status and logs
   kubectl get pods -l app.kubernetes.io/name=olake-ui
   kubectl logs -l app.kubernetes.io/name=olake-ui -f
   ```

3. **OLake Worker issues**
   ```bash
   # Check worker pod status and logs
   kubectl get pods -l app.kubernetes.io/name=olake-workers
   kubectl logs -l app.kubernetes.io/name=olake-workers -f
   
   # Verify worker configuration
   kubectl describe configmap olake-workers-config
   ```

4. **Storage provisioning failures**
   ```bash
   # Check PVC and PV status
   kubectl get pv,pvc
   kubectl describe pvc shared-storage
   
   # Check NFS server pod and StorageClass
   kubectl get pods -l app.kubernetes.io/name=olake-nfs-server
   kubectl describe storageclass nfs-server
   ```

## Uninstallation

### Quick Uninstall (Manual)

```bash
# Uninstall the release
helm uninstall olake --namespace olake

# Optional: Delete namespace and all data
kubectl delete namespace olake
```

**Note:** Some resources are intentionally preserved after `helm uninstall` to prevent accidental data loss:

- **PersistentVolumeClaims (PVCs)**: `olake-shared-storage` and database PVCs are retained to preserve job data, configurations, and historical information
- **NFS Server Resources**: If installed using the built-in NFS server, the following resources persist:
  - `Service/olake-nfs-server`
  - `StatefulSet/olake-nfs-server` 
  - `ClusterRole/olake-nfs-server`
  - `ClusterRoleBinding/olake-nfs-server`
  - `StorageClass/nfs-server`
  - `ServiceAccount/olake-nfs-server`

### Complete Uninstall (Using Script)

For a complete cleanup that removes all resources including those protected by resource policies, use the provided uninstallation script:

```bash
# Navigate to the chart directory
cd helm/olake

# Basic uninstall (removes everything)
./uninstall.sh

# Uninstall with options
./uninstall.sh --help

# Uninstall but keep PVCs for data preservation
./uninstall.sh --keep-pvcs

# Uninstall with custom namespace and release name
./uninstall.sh -n my-namespace -r my-release

# Force delete stuck resources
./uninstall.sh --force

# Keep namespace after cleanup
./uninstall.sh --keep-namespace
```

**Script Options:**
- `-n, --namespace NAMESPACE`: Namespace where OLake is installed (default: olake)
- `-r, --release RELEASE`: Helm release name (default: olake)
- `--force`: Force delete stuck resources without waiting
- `--keep-pvcs`: Keep PersistentVolumeClaims (useful for data preservation)
- `--keep-namespace`: Keep the namespace after cleanup
- `-h, --help`: Show help message

The uninstallation script performs the following cleanup steps:
1. Uninstalls the Helm release
2. Removes DevSpace resources (if any)
3. Deletes remaining pods
4. Removes NFS Server components (StatefulSet, Service, ServiceAccount)
5. Deletes PersistentVolumeClaims (unless --keep-pvcs is specified)
6. Cleans up orphaned PersistentVolumes
7. Removes NFS StorageClass
8. Deletes ClusterRole and ClusterRoleBinding
9. Cleans up any remaining ConfigMaps, Secrets, Services
10. Deletes the namespace (unless --keep-namespace is specified)

## Migrating to v0.0.12

When upgrading from a previous version, the `olake-signup-init` Job must be deleted before running `helm upgrade`. Kubernetes does not allow modifications to a Job's pod template, and the updated image references in this version will cause the upgrade to fail.

```bash
kubectl delete job olake-signup-init -n olake
helm upgrade olake olake/olake
```

## Migrating to v0.0.7

Version 0.0.7 introduces a significant change to how ServiceAccount, RBAC, and Secret resources are managed. By default, `useStandardResources` is now set to `true`, which converts these from Helm Hooks to standard resources. This improves compatibility with ArgoCD and prevents race conditions during updates.

**For New Installations:**
No action needed. The new default (`true`) is the recommended configuration.

**For Existing Installations:**
Upgrading directly may cause `resource already exists` errors because Helm tries to adopt resources that were previously created by hooks.

**Option 1: Maintain Legacy Behavior (Easiest)**
Set the flag to `false` in your `values.yaml` to keep the old hook-based behavior:
```yaml
useStandardResources: false
```

**Option 2: Migrate to Standard Resources (Recommended)**
To adopt the new behavior, you must manually remove the hook annotations and label the resources for Helm adoption before upgrading:

```bash
# 1. ServiceAccount
kubectl annotate serviceaccount olake-workers meta.helm.sh/release-name=olake meta.helm.sh/release-namespace=olake helm.sh/hook- helm.sh/hook-weight- helm.sh/hook-delete-policy- -n olake --overwrite
kubectl label serviceaccount olake-workers app.kubernetes.io/managed-by=Helm -n olake --overwrite

# 2. Role
kubectl annotate role olake-workers meta.helm.sh/release-name=olake meta.helm.sh/release-namespace=olake helm.sh/hook- helm.sh/hook-weight- helm.sh/hook-delete-policy- -n olake --overwrite
kubectl label role olake-workers app.kubernetes.io/managed-by=Helm -n olake --overwrite

# 3. RoleBinding
kubectl annotate rolebinding olake-workers meta.helm.sh/release-name=olake meta.helm.sh/release-namespace=olake helm.sh/hook- helm.sh/hook-weight- helm.sh/hook-delete-policy- -n olake --overwrite
kubectl label rolebinding olake-workers app.kubernetes.io/managed-by=Helm -n olake --overwrite

# 4. Secret
kubectl annotate secret olake-workers-secret meta.helm.sh/release-name=olake meta.helm.sh/release-namespace=olake helm.sh/hook- helm.sh/hook-weight- helm.sh/hook-delete-policy- -n olake --overwrite
kubectl label secret olake-workers-secret app.kubernetes.io/managed-by=Helm -n olake --overwrite

# 5. Perform the upgrade
helm upgrade olake olake/olake
```

## Contributing

We ❤️ contributions! Check our [Bounty Program](https://olake.io/docs/community/issues-and-prs#goodies).

- UI contributions: [CONTRIBUTING.md](../CONTRIBUTING.md)
- Core contributions: [OLake Main Repository](https://github.com/datazip-inc/olake)
- Documentation: [OLake Docs Repository](https://github.com/datazip-inc/olake-docs)

## Support

- [GitHub Issues](https://github.com/datazip-inc/olake-ui/issues)
- [Slack Community](https://join.slack.com/t/getolake/shared_invite/zt-2utw44do6-g4XuKKeqBghBMy2~LcJ4ag)
- [Documentation](https://olake.io/docs)